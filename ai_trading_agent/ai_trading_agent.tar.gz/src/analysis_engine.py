"""
Analysis Engine for AI Trading Agent

This module processes market data to identify patterns and opportunities,
analyzes market psychology and betting patterns, identifies mispriced contracts,
calculates probabilities and expected values, and performs technical analysis.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union, Any
from datetime import datetime, timedelta
import logging
import math
from scipy import stats

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('analysis_engine')

class AnalysisEngine:
    """
    Processes market data to identify patterns and opportunities.
    Analyzes market psychology, betting patterns, and performs technical analysis.
    """
    
    def __init__(self):
        """Initialize the Analysis Engine."""
        logger.info("Initializing Analysis Engine")
    
    def process_market_data(self, market_data: Dict) -> Dict:
        """
        Process comprehensive market data bundle to extract insights.
        
        Args:
            market_data: Comprehensive market data bundle from DataCollector
            
        Returns:
            Dict containing analysis results
        """
        logger.info(f"Processing market data for {market_data.get('market_details', {}).get('ticker', 'unknown')}")
        
        analysis_results = {
            "ticker": market_data.get("market_details", {}).get("ticker", "unknown"),
            "timestamp": datetime.now().isoformat(),
            "price_analysis": {},
            "market_psychology": {},
            "time_factors": {},
            "technical_indicators": {},
            "external_data": {},
            "opportunities": []
        }
        
        # Extract market details
        market_details = market_data.get("market_details", {})
        order_book = market_data.get("order_book", {})
        price_history = market_data.get("price_history", [])
        recent_trades = market_data.get("recent_trades", [])
        
        # Skip analysis if market details are missing
        if not market_details:
            logger.warning("Market details missing, skipping analysis")
            return analysis_results
        
        # Perform price analysis
        analysis_results["price_analysis"] = self.analyze_price(market_details, price_history)
        
        # Analyze market psychology
        analysis_results["market_psychology"] = self.analyze_market_psychology(
            market_details, order_book, recent_trades
        )
        
        # Analyze time factors
        analysis_results["time_factors"] = self.analyze_time_factors(market_details)
        
        # Perform technical analysis
        analysis_results["technical_indicators"] = self.perform_technical_analysis(price_history)
        
        # Analyze external data (placeholder for now)
        analysis_results["external_data"] = {"analyzed": False}
        
        # Identify opportunities
        opportunities = self.identify_opportunities(
            market_details,
            analysis_results["price_analysis"],
            analysis_results["market_psychology"],
            analysis_results["time_factors"],
            analysis_results["technical_indicators"]
        )
        
        analysis_results["opportunities"] = opportunities
        
        return analysis_results
    
    def analyze_price(self, market_details: Dict, price_history: List[Dict]) -> Dict:
        """
        Analyze price data to identify patterns and trends.
        
        Args:
            market_details: Market details from Kalshi API
            price_history: Price history data from Kalshi API
            
        Returns:
            Dict containing price analysis results
        """
        logger.info("Performing price analysis")
        
        # Initialize results
        results = {
            "current_yes_price": None,
            "current_no_price": None,
            "price_range": {"min": None, "max": None},
            "price_volatility": None,
            "recent_momentum": None,
            "price_stability": None,
            "fair_value_estimate": None,
            "mispricing_score": None
        }
        
        # Extract current prices
        results["current_yes_price"] = market_details.get("yes_bid")
        results["current_no_price"] = market_details.get("no_bid")
        
        # Skip further analysis if price history is empty
        if not price_history:
            logger.warning("Price history empty, skipping detailed price analysis")
            return results
        
        # Convert price history to DataFrame for easier analysis
        try:
            df = pd.DataFrame(price_history)
            
            # Convert timestamp strings to datetime objects
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Sort by timestamp
            df = df.sort_values('timestamp')
            
            # Calculate price range
            yes_prices = df.get('yes_price', pd.Series([]))
            if not yes_prices.empty:
                results["price_range"]["min"] = yes_prices.min()
                results["price_range"]["max"] = yes_prices.max()
                
                # Calculate price volatility (standard deviation)
                results["price_volatility"] = yes_prices.std()
                
                # Calculate recent momentum (slope of linear regression)
                if len(yes_prices) >= 5:
                    recent_prices = yes_prices.tail(5)
                    x = np.arange(len(recent_prices))
                    slope, _, _, _, _ = stats.linregress(x, recent_prices)
                    results["recent_momentum"] = slope
                
                # Calculate price stability (inverse of coefficient of variation)
                mean_price = yes_prices.mean()
                if mean_price > 0 and results["price_volatility"] is not None:
                    cv = results["price_volatility"] / mean_price
                    results["price_stability"] = 1 - min(cv, 1)  # Normalize to 0-1
                
                # Estimate fair value based on historical average and recent trend
                results["fair_value_estimate"] = mean_price
                
                # Calculate mispricing score (difference between current and fair value)
                if results["current_yes_price"] is not None and results["fair_value_estimate"] is not None:
                    diff = abs(results["current_yes_price"] - results["fair_value_estimate"])
                    max_diff = max(results["fair_value_estimate"], 1 - results["fair_value_estimate"])
                    results["mispricing_score"] = min(diff / max_diff if max_diff > 0 else 0, 1)
        
        except Exception as e:
            logger.error(f"Error in price analysis: {str(e)}")
        
        return results
    
    def analyze_market_psychology(self, market_details: Dict, order_book: Dict, recent_trades: List[Dict]) -> Dict:
        """
        Analyze market psychology and betting patterns.
        
        Args:
            market_details: Market details from Kalshi API
            order_book: Order book data from Kalshi API
            recent_trades: Recent trades data from Kalshi API
            
        Returns:
            Dict containing market psychology analysis results
        """
        logger.info("Analyzing market psychology")
        
        # Initialize results
        results = {
            "volume": market_details.get("volume", 0),
            "yes_volume": 0,
            "no_volume": 0,
            "volume_ratio": None,
            "order_imbalance": None,
            "trade_frequency": None,
            "average_trade_size": None,
            "large_trades": [],
            "sentiment_indicator": None
        }
        
        # Extract yes and no volume
        results["yes_volume"] = market_details.get("yes_volume", 0)
        results["no_volume"] = market_details.get("no_volume", 0)
        
        # Calculate volume ratio (yes:no)
        if results["no_volume"] > 0:
            results["volume_ratio"] = results["yes_volume"] / results["no_volume"]
        
        # Calculate order book imbalance
        yes_bids = order_book.get("yes_bids", [])
        yes_asks = order_book.get("yes_asks", [])
        
        if yes_bids and yes_asks:
            bid_volume = sum(order.get("size", 0) for order in yes_bids)
            ask_volume = sum(order.get("size", 0) for order in yes_asks)
            
            if ask_volume > 0:
                results["order_imbalance"] = (bid_volume - ask_volume) / (bid_volume + ask_volume)
        
        # Analyze recent trades
        if recent_trades:
            # Calculate trade frequency (trades per hour)
            if len(recent_trades) >= 2:
                first_trade_time = datetime.fromisoformat(recent_trades[-1].get("timestamp", "").replace('Z', '+00:00'))
                last_trade_time = datetime.fromisoformat(recent_trades[0].get("timestamp", "").replace('Z', '+00:00'))
                
                time_diff = (last_trade_time - first_trade_time).total_seconds()
                if time_diff > 0:
                    results["trade_frequency"] = len(recent_trades) / (time_diff / 3600)
            
            # Calculate average trade size
            trade_sizes = [trade.get("size", 0) for trade in recent_trades]
            if trade_sizes:
                results["average_trade_size"] = sum(trade_sizes) / len(trade_sizes)
            
            # Identify large trades (more than 2x average)
            if results["average_trade_size"]:
                threshold = 2 * results["average_trade_size"]
                results["large_trades"] = [
                    trade for trade in recent_trades 
                    if trade.get("size", 0) > threshold
                ]
            
            # Calculate sentiment indicator based on recent trades
            yes_buys = sum(1 for trade in recent_trades if trade.get("side") == "buy" and trade.get("type") == "yes")
            no_buys = sum(1 for trade in recent_trades if trade.get("side") == "buy" and trade.get("type") == "no")
            
            total_trades = yes_buys + no_buys
            if total_trades > 0:
                results["sentiment_indicator"] = (yes_buys - no_buys) / total_trades
        
        return results
    
    def analyze_time_factors(self, market_details: Dict) -> Dict:
        """
        Analyze time-related factors affecting the market.
        
        Args:
            market_details: Market details from Kalshi API
            
        Returns:
            Dict containing time factors analysis results
        """
        logger.info("Analyzing time factors")
        
        # Initialize results
        results = {
            "time_to_expiration": None,
            "time_since_creation": None,
            "expiration_phase": None,
            "time_pressure": None,
            "optimal_entry_window": False,
            "optimal_exit_window": False
        }
        
        # Extract timestamps
        now = datetime.now()
        
        close_time_str = market_details.get("close_time")
        if close_time_str:
            close_time = datetime.fromisoformat(close_time_str.replace('Z', '+00:00'))
            time_to_expiration = (close_time - now).total_seconds() / 3600  # hours
            results["time_to_expiration"] = time_to_expiration
            
            # Determine expiration phase
            if time_to_expiration <= 0.25:  # 15 minutes
                results["expiration_phase"] = "final"
            elif time_to_expiration <= 1:  # 1 hour
                results["expiration_phase"] = "late"
            elif time_to_expiration <= 6:  # 6 hours
                results["expiration_phase"] = "middle"
            else:
                results["expiration_phase"] = "early"
            
            # Calculate time pressure (inverse of time to expiration, normalized)
            max_time = 24  # Normalize based on 24 hours
            results["time_pressure"] = 1 - min(time_to_expiration / max_time, 1)
            
            # Determine optimal entry/exit windows
            # For short-term markets (< 1 hour), optimal entry is early
            if time_to_expiration < 1:
                results["optimal_entry_window"] = time_to_expiration > 0.75  # First 15 minutes
                results["optimal_exit_window"] = time_to_expiration < 0.25  # Last 15 minutes
            # For medium-term markets (1-6 hours)
            elif time_to_expiration < 6:
                results["optimal_entry_window"] = time_to_expiration > 0.8 * 6  # First 20%
                results["optimal_exit_window"] = time_to_expiration < 0.2 * 6  # Last 20%
        
        create_time_str = market_details.get("create_time")
        if create_time_str:
            create_time = datetime.fromisoformat(create_time_str.replace('Z', '+00:00'))
            time_since_creation = (now - create_time).total_seconds() / 3600  # hours
            results["time_since_creation"] = time_since_creation
        
        return results
    
    def perform_technical_analysis(self, price_history: List[Dict]) -> Dict:
        """
        Perform technical analysis on price history data.
        
        Args:
            price_history: Price history data from Kalshi API
            
        Returns:
            Dict containing technical analysis results
        """
        logger.info("Performing technical analysis")
        
        # Initialize results
        results = {
            "trend": None,
            "support_levels": [],
            "resistance_levels": [],
            "moving_averages": {},
            "rsi": None,
            "pattern_recognition": {}
        }
        
        # Skip analysis if price history is insufficient
        if len(price_history) < 10:
            logger.warning("Insufficient price history for technical analysis")
            return results
        
        try:
            # Convert price history to DataFrame
            df = pd.DataFrame(price_history)
            
            # Convert timestamp strings to datetime objects
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Sort by timestamp
            df = df.sort_values('timestamp')
            
            # Extract yes prices
            yes_prices = df.get('yes_price', pd.Series([]))
            
            if not yes_prices.empty:
                # Determine trend (simple linear regression)
                x = np.arange(len(yes_prices))
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, yes_prices)
                
                if slope > 0.01:
                    results["trend"] = "uptrend"
                elif slope < -0.01:
                    results["trend"] = "downtrend"
                else:
                    results["trend"] = "sideways"
                
                # Calculate moving averages
                if len(yes_prices) >= 5:
                    results["moving_averages"]["ma5"] = yes_prices.rolling(window=5).mean().iloc[-1]
                
                if len(yes_prices) >= 10:
                    results["moving_averages"]["ma10"] = yes_prices.rolling(window=10).mean().iloc[-1]
                
                # Calculate RSI (Relative Strength Index)
                if len(yes_prices) >= 14:
                    delta = yes_prices.diff()
                    gain = delta.clip(lower=0)
                    loss = -delta.clip(upper=0)
                    
                    avg_gain = gain.rolling(window=14).mean().iloc[-1]
                    avg_loss = loss.rolling(window=14).mean().iloc[-1]
                    
                    if avg_loss > 0:
                        rs = avg_gain / avg_loss
                        results["rsi"] = 100 - (100 / (1 + rs))
                    else:
                        results["rsi"] = 100
                
                # Identify support and resistance levels
                # Simple method: look for local minima and maxima
                for i in range(2, len(yes_prices) - 2):
                    # Check for local minimum (support)
                    if (yes_prices.iloc[i-2] > yes_prices.iloc[i] and 
                        yes_prices.iloc[i-1] > yes_prices.iloc[i] and 
                        yes_prices.iloc[i] < yes_prices.iloc[i+1] and 
                        yes_prices.iloc[i] < yes_prices.iloc[i+2]):
                        results["support_levels"].append(yes_prices.iloc[i])
                    
                    # Check for local maximum (resistance)
                    if (yes_prices.iloc[i-2] < yes_prices.iloc[i] and 
                        yes_prices.iloc[i-1] < yes_prices.iloc[i] and 
                        yes_prices.iloc[i] > yes_prices.iloc[i+1] and 
                        yes_prices.iloc[i] > yes_prices.iloc[i+2]):
                        results["resistance_levels"].append(yes_prices.iloc[i])
                
                # Pattern recognition
                # Check for double bottom pattern
                if len(yes_prices) >= 10:
                    min_indices = []
                    for i in range(2, len(yes_prices) - 2):
                        if (yes_prices.iloc[i-2] > yes_prices.iloc[i] and 
                            yes_prices.iloc[i-1] > yes_prices.iloc[i] and 
                            yes_prices.iloc[i] < yes_prices.iloc[i+1] and 
                            yes_prices.iloc[i] < yes_prices.iloc[i+2]):
                            min_indices.append(i)
                    
                    if len(min_indices) >= 2:
                        last_two_mins = min_indices[-2:]
                        if last_two_mins[1] - last_two_mins[0] >= 3:  # Ensure some distance between bottoms
                            min1 = yes_prices.iloc[last_two_mins[0]]
                            min2 = yes_prices.iloc[last_two_mins[1]]
                            
                            # Check if bottoms are at similar levels
                            if abs(min1 - min2) / max(min1, min2) < 0.1:
                                results["pattern_recognition"]["double_bottom"] = {
                                    "confidence": 0.7,
                                    "first_bottom": min1,
                                    "second_bottom": min2
                                }
                
                # Check for breakout pattern
                if results["resistance_levels"] and yes_prices.iloc[-1] > max(results["resistance_levels"]):
                    results["pattern_recognition"]["breakout"] = {
                        "confidence": 0.8,
                        "breakout_level": max(results["resistance_levels"])
                    }
                
                # Check for breakdown pattern
                if results["support_levels"] and yes_prices.iloc[-1] < min(results["support_levels"]):
                    results["pattern_recognition"]["breakdown"] = {
                        "confidence": 0.8,
                        "breakdown_level": min(results["support_levels"])
                    }
        
        except Exception as e:
            logger.error(f"Error in technical analysis: {str(e)}")
        
        return results
    
    def identify_opportunities(self, market_details: Dict, price_analysis: Dict, 
                              market_psychology: Dict, time_factors: Dict, 
                              technical_indicators: Dict) -> List[Dict]:
        """
        Identify trading opportunities based on analysis results.
        
        Args:
            market_details: Market details from Kalshi API
            price_analysis: Results from price analysis
            market_psychology: Results from market psychology analysis
            time_factors: Results from time factors analysis
            technical_indicators: Results from technical analysis
            
        Returns:
            List of identified opportunities
        """
        logger.info("Identifying trading opportunities")
        
        opportunities = []
        
        # Extract current prices
        current_yes_price = price_analysis.get("current_yes_price")
        current_no_price = price_analysis.get("current_no_price")
        
        if current_yes_price is None or current_no_price is None:
            logger.warning("Missing current prices, cannot identify opportunities")
            return opportunities
        
        # Check for mispricing opportunity
        mispricing_score = price_analysis.get("mispricing_score")
        if mispricing_score is not None and mispricing_score > 0.2:
            fair_value = price_analysis.get("fair_value_estimate")
            
            if fair_value is not None:
                position_type = "YES" if current_yes_price < fair_value else "NO"
                
                opportunities.append({
                    "type": "mispricing",
                    "position": position_type,
                    "current_price": current_yes_price if position_type == "YES" else current_no_price,
                    "target_price": fair_value if position_type == "YES" else 1 - fair_value,
                    "confidence": (mispricing_score - 0.2) * 1.25,  # Scale 0.2-1.0 to 0-1.0
                    "reasoning": f"Market appears mispriced based on historical data. Fair value estimate: {fair_value:.2f}"
                })
        
        # Check for momentum opportunity
        recent_momentum = price_analysis.get("recent_momentum")
        if recent_momentum is not None:
            momentum_threshold = 0.02
            
            if abs(recent_momentum) > momentum_threshold:
                position_type = "YES" if recent_momentum > 0 else "NO"
                
                # Calculate target price based on momentum
                target_price = current_yes_price + (recent_momentum * 3) if position_type == "YES" else current_no_price + (-recent_momentum * 3)
                target_price = max(0.01, min(0.99, target_price))
                
                opportunities.append({
                    "type": "momentum",
                    "position": position_type,
                    "current_price": current_yes_price if position_type == "YES" else current_no_price,
                    "target_price": target_price,
                    "confidence": min((abs(recent_momentum) - momentum_threshold) * 10, 0.9),
                    "reasoning": f"Strong {'positive' if recent_momentum > 0 else 'negative'} price momentum detected"
                })
        
        # Check for market psychology opportunity
        sentiment_indicator = market_psychology.get("sentiment_indicator")
        order_imbalance = market_psychology.get("order_imbalance")
        
        if sentiment_indicator is not None and order_imbalance is not None:
            # Look for alignment between sentiment and order imbalance
            if abs(sentiment_indicator) > 0.3 and abs(order_imbalance) > 0.3:
                if (sentiment_indicator > 0 and order_imbalance > 0) or (sentiment_indicator < 0 and order_imbalance < 0):
                    position_type = "YES" if sentiment_indicator > 0 else "NO"
                    
                    # Calculate confidence based on strength of alignment
                    confidence = min(abs(sentiment_indicator) * abs(order_imbalance) * 2, 0.9)
                    
                    opportunities.append({
                        "type": "market_psychology",
                        "position": position_type,
                        "current_price": current_yes_price if position_type == "YES" else current_no_price,
                        "target_price": current_yes_price * 1.2 if position_type == "YES" else current_no_price * 1.2,
                        "confidence": confidence,
                        "reasoning": f"Strong alignment between market sentiment and order book imbalance favoring {position_type} position"
                    })
        
        # Check for technical pattern opportunity
        pattern_recognition = technical_indicators.get("pattern_recognition", {})
        
        if "double_bottom" in pattern_recognition:
            opportunities.append({
                "type": "technical_pattern",
                "position": "YES",
                "current_price": current_yes_price,
                "target_price": current_yes_price * 1.3,
                "confidence": pattern_recognition["double_bottom"]["confidence"],
                "reasoning": "Double bottom pattern detected, suggesting potential upward reversal"
            })
        
        if "breakout" in pattern_recognition:
            opportunities.append({
                "type": "technical_pattern",
                "position": "YES",
                "current_price": current_yes_price,
                "target_price": current_yes_price * 1.2,
                "confidence": pattern_recognition["breakout"]["confidence"],
                "reasoning": f"Breakout detected above resistance level {pattern_recognition['breakout']['breakout_level']:.2f}"
            })
        
        if "breakdown" in pattern_recognition:
            opportunities.append({
                "type": "technical_pattern",
                "position": "NO",
                "current_price": current_no_price,
                "target_price": current_no_price * 1.2,
                "confidence": pattern_recognition["breakdown"]["confidence"],
                "reasoning": f"Breakdown detected below support level {pattern_recognition['breakdown']['breakdown_level']:.2f}"
            })
        
        # Check for time-based opportunity
        if time_factors.get("optimal_entry_window") and time_factors.get("time_pressure") is not None:
            # Determine position based on other factors
            position_type = None
            
            if recent_momentum is not None:
                position_type = "YES" if recent_momentum > 0 else "NO"
            elif sentiment_indicator is not None:
                position_type = "YES" if sentiment_indicator > 0 else "NO"
            
            if position_type:
                opportunities.append({
                    "type": "time_based",
                    "position": position_type,
                    "current_price": current_yes_price if position_type == "YES" else current_no_price,
                    "target_price": current_yes_price * 1.15 if position_type == "YES" else current_no_price * 1.15,
                    "confidence": 0.6 + (time_factors.get("time_pressure", 0) * 0.3),
                    "reasoning": "Optimal entry window based on time to expiration"
                })
        
        return opportunities
    
    def calculate_confidence_score(self, opportunity: Dict, market_details: Dict, 
                                  price_analysis: Dict, market_psychology: Dict, 
                                  time_factors: Dict, technical_indicators: Dict) -> float:
        """
        Calculate comprehensive confidence score for a trading opportunity.
        
        Args:
            opportunity: Trading opportunity
            market_details: Market details from Kalshi API
            price_analysis: Results from price analysis
            market_psychology: Results from market psychology analysis
            time_factors: Results from time factors analysis
            technical_indicators: Results from technical analysis
            
        Returns:
            Confidence score (0-100)
        """
        logger.info(f"Calculating confidence score for {opportunity.get('type')} opportunity")
        
        # Initialize component scores
        price_score = 0
        psychology_score = 0
        time_score = 0
        technical_score = 0
        external_score = 0
        
        # Calculate price analysis score (25%)
        if price_analysis.get("mispricing_score") is not None:
            price_score += min(price_analysis["mispricing_score"] * 100, 25)
        
        if price_analysis.get("recent_momentum") is not None:
            momentum_alignment = 1 if (
                (opportunity.get("position") == "YES" and price_analysis["recent_momentum"] > 0) or
                (opportunity.get("position") == "NO" and price_analysis["recent_momentum"] < 0)
            ) else -1
            
            price_score += momentum_alignment * min(abs(price_analysis["recent_momentum"]) * 500, 25)
        
        # Normalize price score to 0-25 range
        price_score = max(0, min(price_score, 25))
        
        # Calculate market psychology score (25%)
        if market_psychology.get("sentiment_indicator") is not None:
            sentiment_alignment = 1 if (
                (opportunity.get("position") == "YES" and market_psychology["sentiment_indicator"] > 0) or
                (opportunity.get("position") == "NO" and market_psychology["sentiment_indicator"] < 0)
            ) else -1
            
            psychology_score += sentiment_alignment * min(abs(market_psychology["sentiment_indicator"]) * 50, 12.5)
        
        if market_psychology.get("order_imbalance") is not None:
            imbalance_alignment = 1 if (
                (opportunity.get("position") == "YES" and market_psychology["order_imbalance"] > 0) or
                (opportunity.get("position") == "NO" and market_psychology["order_imbalance"] < 0)
            ) else -1
            
            psychology_score += imbalance_alignment * min(abs(market_psychology["order_imbalance"]) * 50, 12.5)
        
        # Normalize psychology score to 0-25 range
        psychology_score = max(0, min(psychology_score, 25))
        
        # Calculate time factors score (20%)
        if time_factors.get("optimal_entry_window"):
            time_score += 10
        
        if time_factors.get("time_pressure") is not None:
            # Higher confidence for short-term opportunities
            time_score += time_factors["time_pressure"] * 10
        
        # Normalize time score to 0-20 range
        time_score = max(0, min(time_score, 20))
        
        # Calculate technical indicators score (15%)
        if technical_indicators.get("trend") is not None:
            trend_alignment = 1 if (
                (opportunity.get("position") == "YES" and technical_indicators["trend"] == "uptrend") or
                (opportunity.get("position") == "NO" and technical_indicators["trend"] == "downtrend")
            ) else 0
            
            technical_score += trend_alignment * 5
        
        if technical_indicators.get("rsi") is not None:
            rsi = technical_indicators["rsi"]
            
            if opportunity.get("position") == "YES" and rsi < 30:
                # Oversold condition for YES position
                technical_score += 5
            elif opportunity.get("position") == "NO" and rsi > 70:
                # Overbought condition for NO position
                technical_score += 5
        
        pattern_recognition = technical_indicators.get("pattern_recognition", {})
        if pattern_recognition:
            for pattern, details in pattern_recognition.items():
                pattern_alignment = 1 if (
                    (opportunity.get("position") == "YES" and pattern in ["double_bottom", "breakout"]) or
                    (opportunity.get("position") == "NO" and pattern in ["breakdown"])
                ) else -1
                
                technical_score += pattern_alignment * (details.get("confidence", 0.5) * 10)
        
        # Normalize technical score to 0-15 range
        technical_score = max(0, min(technical_score, 15))
        
        # Calculate external data score (15%)
        # This would typically involve analysis of external factors
        # For now, we'll use a placeholder value
        external_score = 7.5
        
        # Calculate total confidence score
        total_score = price_score + psychology_score + time_score + technical_score + external_score
        
        # Apply opportunity-specific adjustments
        if opportunity.get("type") == "mispricing":
            # Boost confidence for significant mispricing
            mispricing_score = price_analysis.get("mispricing_score", 0)
            total_score *= (1 + min(mispricing_score, 0.5))
        
        elif opportunity.get("type") == "momentum":
            # Boost confidence for strong momentum
            momentum = abs(price_analysis.get("recent_momentum", 0))
            total_score *= (1 + min(momentum * 5, 0.3))
        
        # Ensure score is within 0-100 range
        total_score = max(0, min(total_score, 100))
        
        return total_score
    
    def rank_opportunities(self, opportunities: List[Dict], market_details: Dict, 
                          price_analysis: Dict, market_psychology: Dict, 
                          time_factors: Dict, technical_indicators: Dict) -> List[Dict]:
        """
        Rank trading opportunities based on confidence scores.
        
        Args:
            opportunities: List of trading opportunities
            market_details: Market details from Kalshi API
            price_analysis: Results from price analysis
            market_psychology: Results from market psychology analysis
            time_factors: Results from time factors analysis
            technical_indicators: Results from technical analysis
            
        Returns:
            List of ranked opportunities with confidence scores
        """
        logger.info(f"Ranking {len(opportunities)} trading opportunities")
        
        # Calculate confidence scores for each opportunity
        for opportunity in opportunities:
            confidence_score = self.calculate_confidence_score(
                opportunity, market_details, price_analysis, 
                market_psychology, time_factors, technical_indicators
            )
            
            opportunity["confidence_score"] = confidence_score
        
        # Sort opportunities by confidence score (descending)
        ranked_opportunities = sorted(
            opportunities, 
            key=lambda x: x.get("confidence_score", 0), 
            reverse=True
        )
        
        return ranked_opportunities


# Example usage
if __name__ == "__main__":
    # Create analysis engine
    analysis_engine = AnalysisEngine()
    
    # Example market data (simplified for demonstration)
    market_data = {
        "market_details": {
            "ticker": "BTC-PRICE-83750-83999-12PM",
            "yes_bid": 0.33,
            "no_bid": 0.67,
            "volume": 10000,
            "yes_volume": 6000,
            "no_volume": 4000,
            "close_time": (datetime.now() + timedelta(hours=1)).isoformat() + "Z"
        },
        "order_book": {
            "yes_bids": [{"price": 0.33, "size": 500}, {"price": 0.32, "size": 700}],
            "yes_asks": [{"price": 0.34, "size": 300}, {"price": 0.35, "size": 400}]
        },
        "price_history": [
            {"timestamp": (datetime.now() - timedelta(minutes=50)).isoformat(), "yes_price": 0.25},
            {"timestamp": (datetime.now() - timedelta(minutes=40)).isoformat(), "yes_price": 0.27},
            {"timestamp": (datetime.now() - timedelta(minutes=30)).isoformat(), "yes_price": 0.29},
            {"timestamp": (datetime.now() - timedelta(minutes=20)).isoformat(), "yes_price": 0.31},
            {"timestamp": (datetime.now() - timedelta(minutes=10)).isoformat(), "yes_price": 0.33}
        ],
        "recent_trades": [
            {"timestamp": (datetime.now() - timedelta(minutes=5)).isoformat(), "side": "buy", "type": "yes", "size": 100},
            {"timestamp": (datetime.now() - timedelta(minutes=7)).isoformat(), "side": "buy", "type": "yes", "size": 150},
            {"timestamp": (datetime.now() - timedelta(minutes=9)).isoformat(), "side": "buy", "type": "no", "size": 80}
        ]
    }
    
    # Process market data
    analysis_results = analysis_engine.process_market_data(market_data)
    
    # Print identified opportunities
    print(f"Identified {len(analysis_results['opportunities'])} trading opportunities:")
    for i, opportunity in enumerate(analysis_results["opportunities"]):
        print(f"{i+1}. {opportunity['type']} opportunity: {opportunity['position']} at {opportunity['current_price']:.2f}")
        print(f"   Target: {opportunity['target_price']:.2f}, Confidence: {opportunity['confidence']:.2f}")
        print(f"   Reasoning: {opportunity['reasoning']}")
        print()
