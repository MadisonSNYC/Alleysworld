# AI Trading Agent Documentation

## Overview

The AI Trading Agent is designed to analyze Kalshi prediction markets, generate trade recommendations, and execute trades based on user-defined strategies. The agent focuses on short-term opportunities (typically 1-hour windows) for consistent small gains (5-20%).

## Components

The AI Trading Agent consists of five core components:

1. **Data Collection Module**: Interfaces with Kalshi API to retrieve market data
2. **Analysis Engine**: Processes market data to identify patterns and opportunities
3. **Strategy Processor**: Interprets user-defined strategy parameters and applies them to opportunities
4. **Recommendation Generator**: Creates structured trade recommendations with confidence scores
5. **Execution Manager**: Handles trade execution, monitoring, and exit strategies

## Installation

```bash
# Clone the repository
git clone https://github.com/your-repo/ai-trading-agent.git
cd ai-trading-agent

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Basic Usage

```python
from ai_trading_agent.src.data_collector import KalshiAPIClient, DataCollector
from ai_trading_agent.src.analysis_engine import AnalysisEngine
from ai_trading_agent.src.strategy_processor import StrategyProcessor
from ai_trading_agent.src.recommendation_generator import RecommendationGenerator
from ai_trading_agent.src.execution_manager import ExecutionManager

# Initialize API client
api_client = KalshiAPIClient(email="your_email@example.com", password="your_password")
api_client.login()

# Initialize components
data_collector = DataCollector(api_client)
analysis_engine = AnalysisEngine()
strategy_processor = StrategyProcessor()
recommendation_generator = RecommendationGenerator()
execution_manager = ExecutionManager(api_client)

# Define strategy
strategy_params = {
    "budget": 100.00,
    "targetProfit": 15,
    "categories": ["crypto", "sports"],
    "timeHorizon": "1h",
    "maxSimultaneousPositions": 5,
    "riskLevel": 6,
    "minConfidence": 65,
    "positionSizing": {
        "maxPerTrade": 20,
        "scaling": "confidence"
    },
    "executionMode": "manual"  # or "yolo" for automatic execution
}

# Load strategy
strategy_processor.load_strategy("my_strategy", strategy_params)

# Collect market data
crypto_markets = data_collector.get_markets_by_category("crypto")
short_term_markets = data_collector.get_markets_by_time_horizon(1)  # 1 hour

# Process markets
for market in short_term_markets[:5]:  # Process first 5 markets
    ticker = market["ticker"]
    market_data = data_collector.get_market_data_bundle(ticker)
    
    # Analyze market data
    analysis_results = analysis_engine.process_market_data(market_data)
    
    # Apply strategy to opportunities
    filtered_opportunities = strategy_processor.apply_strategy(
        "my_strategy", analysis_results["opportunities"]
    )
    
    # Generate recommendations
    recommendations = recommendation_generator.generate_recommendations(
        filtered_opportunities, market_data
    )
    
    # Execute trades (if in YOLO mode)
    for recommendation in recommendations:
        execution_result = execution_manager.execute_trade(
            recommendation, strategy_params["executionMode"]
        )
        print(f"Execution result: {execution_result['status']}")

# Monitor positions
while execution_manager.active_positions:
    # Collect latest market data for active positions
    market_data = {}
    for position_id, position in execution_manager.active_positions.items():
        ticker = position["ticker"]
        market_data[ticker] = data_collector.get_market_data_bundle(ticker)
    
    # Monitor positions and execute exits if needed
    actions = execution_manager.monitor_positions(market_data)
    
    # Print actions
    for action in actions:
        print(f"Action: {action['action']} for position {action['position_id']}")
    
    # Wait before next check
    time.sleep(30)

# Get performance metrics
performance = execution_manager.get_performance_metrics()
print(f"Win rate: {performance['win_rate']:.2f}%")
print(f"Total profit: ${performance['total_profit']:.2f}")
```

## Strategy Parameters

The AI Trading Agent accepts the following strategy parameters:

| Parameter | Type | Description |
|-----------|------|-------------|
| `budget` | float | Total amount to invest (USD) |
| `targetProfit` | float | Target percentage gain |
| `categories` | list | Market categories to focus on (e.g., "crypto", "sports") |
| `timeHorizon` | string | Time horizon for trades (e.g., "1h", "30m") |
| `maxSimultaneousPositions` | int | Maximum number of concurrent trades |
| `riskLevel` | int | Risk tolerance (1-10) |
| `minConfidence` | float | Minimum confidence score for recommendations (0-100) |
| `positionSizing.maxPerTrade` | float | Maximum percentage of budget per trade |
| `positionSizing.scaling` | string | How to scale position size ("equal", "confidence", "risk") |
| `executionMode` | string | "manual" or "yolo" |

## Trade Recommendation Format

The AI Trading Agent generates recommendations in the following format:

```json
{
  "id": "abc12345",
  "asset": "BTC-83750-83999-12PM",
  "position": "YES",
  "currentPrice": 33,
  "entryPrice": 33,
  "contracts": 7,
  "cost": 2.31,
  "targetExit": "48-50",
  "stopLoss": 22,
  "confidence": 82,
  "expectedReturn": 45.5,
  "timeWindow": "11:00-12:00 EDT",
  "reasoning": "BTC showing strong upward momentum in the last 30 minutes with support at $83,700. Order book shows thin resistance up to $84,000, increasing probability of YES outcome. 7:3 YES:NO volume ratio in last 15 minutes suggests positive sentiment."
}
```

## Trading Strategies

### Rapid Trading Strategy

This strategy focuses on markets with short time windows (1-hour or less) and aims to identify advantageous entry points early in the window.

```python
rapid_trading_strategy = {
    "budget": 100.00,
    "targetProfit": 15,
    "categories": ["crypto"],
    "timeHorizon": "1h",
    "maxSimultaneousPositions": 3,
    "riskLevel": 7,
    "minConfidence": 70,
    "positionSizing": {
        "maxPerTrade": 30,
        "scaling": "confidence"
    },
    "executionMode": "yolo"
}
```

### Entry/Exit Scalping

This strategy sets buy parameters at favorable price points and automatic sell parameters at 5-10% gain targets, repeating the process multiple times within short timeframes.

```python
scalping_strategy = {
    "budget": 200.00,
    "targetProfit": 8,
    "categories": ["crypto", "finance"],
    "timeHorizon": "30m",
    "maxSimultaneousPositions": 10,
    "riskLevel": 5,
    "minConfidence": 60,
    "positionSizing": {
        "maxPerTrade": 10,
        "scaling": "equal"
    },
    "executionMode": "yolo"
}
```

### Market Psychology Analysis

This strategy analyzes betting patterns and price movements to identify market sentiment shifts and capitalize on discrepancies between perceived and actual probabilities.

```python
psychology_strategy = {
    "budget": 150.00,
    "targetProfit": 20,
    "categories": ["sports", "politics"],
    "timeHorizon": "2h",
    "maxSimultaneousPositions": 4,
    "riskLevel": 8,
    "minConfidence": 75,
    "positionSizing": {
        "maxPerTrade": 25,
        "scaling": "risk"
    },
    "executionMode": "manual"
}
```

### Continuous Small Gains Strategy

This strategy focuses on 5-20% returns per trade rather than large, risky positions, compounding gains through multiple trades.

```python
small_gains_strategy = {
    "budget": 500.00,
    "targetProfit": 7,
    "categories": ["crypto", "sports", "finance"],
    "timeHorizon": "1h",
    "maxSimultaneousPositions": 8,
    "riskLevel": 4,
    "minConfidence": 80,
    "positionSizing": {
        "maxPerTrade": 15,
        "scaling": "confidence"
    },
    "executionMode": "yolo"
}
```

## Psychological Factors in Trading

The AI Trading Agent incorporates several psychological factors that influence trading decisions:

### Market Sentiment

The agent tracks market sentiment on a scale from fear to greed, adjusting position sizes accordingly. In high-fear markets, the agent reduces size for YES positions and increases size for NO positions, and vice versa in high-greed markets.

### Crowd Behavior

The agent analyzes crowd behavior to identify potential contrarian opportunities. When the crowd is heavily biased in one direction, the agent may take the opposite position if other factors support it.

### Recency Bias

The agent accounts for recency bias, which is the tendency to overweight recent events. After a series of winning trades, the agent becomes more cautious to avoid overconfidence, and after losing trades, it may become more selective.

## Performance Metrics

The AI Trading Agent tracks the following performance metrics:

- **Win Rate**: Percentage of trades that achieve profit targets
- **Average Return**: Mean percentage return across all trades
- **Total Profit**: Sum of profits from all trades
- **Risk-Adjusted Return**: Return relative to maximum drawdown
- **Execution Accuracy**: Percentage of trades executed at or better than recommended prices

## Best Practices

1. **Start with Manual Mode**: Begin with manual execution mode to review recommendations before committing capital.

2. **Diversify Categories**: Spread your budget across different market categories to reduce risk.

3. **Adjust Risk Level**: Start with a lower risk level (3-5) and increase gradually as you become comfortable with the system.

4. **Monitor Performance**: Regularly review performance metrics to identify which strategies work best for you.

5. **Limit Position Size**: Keep individual position sizes small (5-20% of budget) to manage risk.

6. **Set Clear Exit Criteria**: Always have predefined exit points for both profit-taking and stop losses.

7. **Be Patient**: The strategy focuses on consistent small gains rather than occasional big wins.

## Troubleshooting

### API Connection Issues

If you experience connection issues with the Kalshi API:

```python
# Retry login with increased timeout
api_client = KalshiAPIClient(email="your_email@example.com", password="your_password")
api_client.session.timeout = 30  # Increase timeout to 30 seconds
api_client.login()
```

### Rate Limiting

If you encounter rate limiting:

```python
# Increase rate limit delay
data_collector = DataCollector(api_client)
data_collector.api_client.rate_limit_delay = 0.5  # 500ms between requests
```

### Memory Usage

For long-running sessions, clear caches periodically:

```python
# Clear caches
data_collector.markets_cache = {}
data_collector.order_books_cache = {}
data_collector.market_history_cache = {}
data_collector.last_update_time = {}
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
